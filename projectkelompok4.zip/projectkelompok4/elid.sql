-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 15 Nov 2022 pada 05.15
-- Versi server: 10.4.25-MariaDB
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elid`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `jasa_service`
--

CREATE TABLE `jasa_service` (
  `id_jasa_service` varchar(10) NOT NULL,
  `id_mekanik` varchar(10) NOT NULL,
  `jenis_jasa_service` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jasa_service`
--

INSERT INTO `jasa_service` (`id_jasa_service`, `id_mekanik`, `jenis_jasa_service`) VALUES
('JSC01', 'MKN02', 'Rusak Berat'),
('JSC02', 'MKN01', 'Rusak Ringan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mekanik`
--

CREATE TABLE `mekanik` (
  `id_mekanik` varchar(10) NOT NULL,
  `nm_mekanik` varchar(35) NOT NULL,
  `nohp` varchar(12) NOT NULL,
  `alamat_mekanik` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mekanik`
--

INSERT INTO `mekanik` (`id_mekanik`, `nm_mekanik`, `nohp`, `alamat_mekanik`) VALUES
('MKN01', 'budi', '083030929223', 'jln.abcd'),
('MKN02', 'Tono', '083180807912', 'Jln.xyz'),
('MKN03', 'gggg', '999999', 'jln karang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mknk_plgn`
--

CREATE TABLE `mknk_plgn` (
  `id_mekanik` varchar(10) NOT NULL,
  `id_pelanggan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mknk_plgn`
--

INSERT INTO `mknk_plgn` (`id_mekanik`, `id_pelanggan`) VALUES
('MKN01', 'PLG01'),
('MKN02', 'PLG02');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` varchar(10) NOT NULL,
  `nm_pelanggan` varchar(35) NOT NULL,
  `alamat_pelanggan` varchar(30) NOT NULL,
  `nohp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nm_pelanggan`, `alamat_pelanggan`, `nohp`) VALUES
('PLG01', 'Gugun', 'Pariaman', '083030929223'),
('PLG02', 'agung', 'pariaman', '083030929223'),
('PLG03', 'annisya', 'padang', '0899999');

-- --------------------------------------------------------

--
-- Struktur dari tabel `service`
--

CREATE TABLE `service` (
  `id_service` varchar(10) NOT NULL,
  `id_pelanggan` varchar(10) NOT NULL,
  `tgl_service` date NOT NULL,
  `jenis_service` varchar(20) NOT NULL,
  `nopol` varchar(10) NOT NULL,
  `merk_kendaraan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `service`
--

INSERT INTO `service` (`id_service`, `id_pelanggan`, `tgl_service`, `jenis_service`, `nopol`, `merk_kendaraan`) VALUES
('SRV01', 'PLG01', '2022-10-28', 'Bongkar Mesin', 'BA 5820 AN', 'Beat'),
('SRV02', 'PLG02', '2022-10-28', 'Ganti Oli', 'BA 2021 DN', 'Vario');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sparepart`
--

CREATE TABLE `sparepart` (
  `id_sparepart` varchar(10) NOT NULL,
  `nm_sparepart` varchar(35) NOT NULL,
  `hrg_sparepart` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `sparepart`
--

INSERT INTO `sparepart` (`id_sparepart`, `nm_sparepart`, `hrg_sparepart`) VALUES
('SPR01', 'oli', 50000),
('SPR02', 'ban', 100000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` varchar(10) NOT NULL,
  `id_pelanggan` varchar(10) NOT NULL,
  `id_mekanik` varchar(10) NOT NULL,
  `id_sparepart` varchar(10) NOT NULL,
  `id_service` varchar(10) NOT NULL,
  `id_jasa_service` varchar(10) NOT NULL,
  `tgl_transaksi` date NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_pelanggan`, `id_mekanik`, `id_sparepart`, `id_service`, `id_jasa_service`, `tgl_transaksi`, `jumlah`) VALUES
('TRS01', 'PLG01', 'MKN01', 'SPR01', 'SRV01', 'JSC01', '2022-10-27', 1),
('TRS02', 'PLG02', 'MKN02', 'SPR02', 'SRV01', 'JSC02', '2022-10-27', 2),
('TRS13', 'PLG01', 'MKN02', 'SPR01', 'SRV02', 'JSC01', '2022-11-13', 5),
('TRS20', 'PLG03', 'MKN02', 'SPR02', 'SRV02', 'JSC02', '2022-11-13', 5),
('TRS21', 'PLG02', 'MKN02', 'SPR02', 'SRV02', 'JSC02', '2022-11-15', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `iduser` char(20) NOT NULL,
  `namauser` varchar(30) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `level` char(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`iduser`, `namauser`, `username`, `password`, `level`) VALUES
('USR01', 'budi', 'budi', 'budi', 'pelanggan'),
('USR02', 'tono', 'tono', 'tono', 'pelanggan'),
('USR03', 'admin', 'admin', 'admin', 'admin'),
('USR04', 'agung', 'agung', 'agung', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `jasa_service`
--
ALTER TABLE `jasa_service`
  ADD PRIMARY KEY (`id_jasa_service`);

--
-- Indeks untuk tabel `mekanik`
--
ALTER TABLE `mekanik`
  ADD PRIMARY KEY (`id_mekanik`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indeks untuk tabel `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id_service`);

--
-- Indeks untuk tabel `sparepart`
--
ALTER TABLE `sparepart`
  ADD PRIMARY KEY (`id_sparepart`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
