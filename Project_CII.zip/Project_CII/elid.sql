-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2022 at 09:24 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elid`
--

-- --------------------------------------------------------

--
-- Table structure for table `jasa_service`
--

CREATE TABLE `jasa_service` (
  `id_jasa_service` varchar(10) NOT NULL,
  `id_mekanik` varchar(10) NOT NULL,
  `jenis_jasa_service` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jasa_service`
--

INSERT INTO `jasa_service` (`id_jasa_service`, `id_mekanik`, `jenis_jasa_service`) VALUES
('JSC01', 'MKN02', 'Rusak Berat'),
('JSC02', 'MKN01', 'Rusak Ringan');

-- --------------------------------------------------------

--
-- Table structure for table `mekanik`
--

CREATE TABLE `mekanik` (
  `id_mekanik` varchar(10) NOT NULL,
  `nm_mekanik` varchar(35) NOT NULL,
  `nohp` varchar(12) NOT NULL,
  `alamat_mekanik` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mekanik`
--

INSERT INTO `mekanik` (`id_mekanik`, `nm_mekanik`, `nohp`, `alamat_mekanik`) VALUES
('MKN01', 'budi', '083030929223', 'jln.abcd'),
('MKN02', 'Tono', '083180807912', 'Jln.xyz'),
('MKN03', 'gggg', '999999', 'jln karang');

-- --------------------------------------------------------

--
-- Table structure for table `mknk_plgn`
--

CREATE TABLE `mknk_plgn` (
  `id_mekanik` varchar(10) NOT NULL,
  `id_pelanggan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mknk_plgn`
--

INSERT INTO `mknk_plgn` (`id_mekanik`, `id_pelanggan`) VALUES
('MKN01', 'PLG01'),
('MKN02', 'PLG02');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` varchar(10) NOT NULL,
  `nm_pelanggan` varchar(35) NOT NULL,
  `alamat_pelanggan` varchar(30) NOT NULL,
  `nohp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nm_pelanggan`, `alamat_pelanggan`, `nohp`) VALUES
('PLG01', 'Gugun', 'Pariaman', '083030929223'),
('PLG02', 'agung', 'pariaman', '083030929223'),
('PLG03', 'annisya', 'padang', '0899999');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id_service` varchar(10) NOT NULL,
  `id_pelanggan` varchar(10) NOT NULL,
  `tgl_service` date NOT NULL,
  `jenis_service` varchar(20) NOT NULL,
  `nopol` varchar(10) NOT NULL,
  `merk_kendaraan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id_service`, `id_pelanggan`, `tgl_service`, `jenis_service`, `nopol`, `merk_kendaraan`) VALUES
('SRV01', 'PLG01', '2022-10-28', 'Bongkar Mesin', 'BA 5820 AN', 'Beat'),
('SRV02', 'PLG02', '2022-10-28', 'Ganti Oli', 'BA 2021 DN', 'Vario');

-- --------------------------------------------------------

--
-- Table structure for table `sparepart`
--

CREATE TABLE `sparepart` (
  `id_sparepart` varchar(10) NOT NULL,
  `nm_sparepart` varchar(35) NOT NULL,
  `hrg_sparepart` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sparepart`
--

INSERT INTO `sparepart` (`id_sparepart`, `nm_sparepart`, `hrg_sparepart`) VALUES
('SPR01', 'oli', 50000),
('SPR02', 'ban', 100000);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` varchar(10) NOT NULL,
  `id_pelanggan` varchar(10) NOT NULL,
  `id_mekanik` varchar(10) NOT NULL,
  `id_sparepart` varchar(10) NOT NULL,
  `id_service` varchar(10) NOT NULL,
  `id_jasa_service` varchar(10) NOT NULL,
  `tgl_transaksi` date NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_pelanggan`, `id_mekanik`, `id_sparepart`, `id_service`, `id_jasa_service`, `tgl_transaksi`, `jumlah`) VALUES
('TRS01', 'PLG01', 'MKN01', 'SPR01', 'SRV01', 'JSC01', '2022-10-27', 1),
('TRS02', 'PLG02', 'MKN02', 'SPR02', 'SRV01', 'JSC02', '2022-10-27', 2),
('TRS13', 'PLG01', 'MKN02', 'SPR01', 'SRV02', 'JSC01', '2022-11-13', 5),
('TRS20', 'PLG03', 'MKN02', 'SPR02', 'SRV02', 'JSC02', '2022-11-13', 5),
('TRS21', 'PLG02', 'MKN02', 'SPR02', 'SRV02', 'JSC02', '2022-11-15', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `iduser` char(20) NOT NULL,
  `namauser` varchar(30) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `level` char(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`iduser`, `namauser`, `username`, `password`, `level`) VALUES
('USR01', 'budi', 'budi', 'budi', 'pelanggan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jasa_service`
--
ALTER TABLE `jasa_service`
  ADD PRIMARY KEY (`id_jasa_service`);

--
-- Indexes for table `mekanik`
--
ALTER TABLE `mekanik`
  ADD PRIMARY KEY (`id_mekanik`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id_service`);

--
-- Indexes for table `sparepart`
--
ALTER TABLE `sparepart`
  ADD PRIMARY KEY (`id_sparepart`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`iduser`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
