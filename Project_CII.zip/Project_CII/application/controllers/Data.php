<?php

class Data extends CI_Controller{
    public function index()
    {
        $data['user']= $this->t_data->tampil_data()-> 
        result();
        $this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		 	$this->load->view('v_data', $data);
		$this->load->view('templates/footer');
	
    }

    public function tambah_aksi()
    {
        $iduser = $this->input->post('iduser');
        $namauser = $this->input->post('namauser');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $level = $this->input->post('level');
       
    
        $data = array(
            'iduser' => $iduser,
            'namauser' => $namauser,
            'username' => $username,
            'password' => $password,
            'level' => $level,

        );

        $this->t_data->input_data($data, 'user');
        redirect('data/index');
        
    }

    public function hapus ($iduser)
{
    $where = array ('iduser' => $iduser);
    $this->t_data->hapus_data($where, 'user');
    redirect ('data/index');
}

    public function edit ($iduser)
{
    $where = array('iduser' => $iduser);
    $data['data'] = $this->t_data->edit_data($where, 'user')->result();
    $this->load->view('templates/header');
    $this->load->view('templates/sidebar');
    $this->load->view('edit', $data);
    $this->load->view('templates/footer');
}

public function update()
{
$iduser= $this->input->post('iduser');
$namauser= $this->input->post('namauser');
$username= $this->input->post('username');
$password= $this->input->post('password');
$level = $this->input->post('level');

$data = array(
    'iduser' => $iduser,
    'namauser' => $namauser,
    'username' => $username,
    'password' => $password,
    'level' => $level,
);

$where = array(
 'iduser' => $iduser
);

$this->t_data->update_data($where,$data,'user');
redirect('data/index');
}

public function print(){
    $data['data'] = $this->t_data->tampil_data("user")->result();
    $this->load->view('print_data', $data);
}

}
?>