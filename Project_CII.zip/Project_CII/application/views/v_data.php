<div class="content-wrapper">
<section class="content-header">
      <h1>
       Data User
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="user"><i class="fa fa-user"></i> user</a></li>
      </ol>
    </section>

    <section class="content">
        <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i>Tambah Data</button>
        <a clss="btn btn-primary" href=" <?php echo base_url('data/print') ?>"> <i class="fa fa-print"></i> Print</a>
        <table class="table">
            <tr>
                <th> No</th>
                <th>Id user</th>
                <th>Nama User</th>
                <th>Username</th>
                <th>Password</th>
                <th>Level</th>
                <th>Edit</th>
                <th>Hapus</th>

                
            </tr>

            <?php
            $no = 1;
            foreach ($user as $user):?>
            <tr>
                <td><?php echo $no++?></td>  
                <td><?php echo $user->iduser ?></td> 
                <td><?php echo $user->namauser ?></td>  
                <td><?php echo $user->username ?></td>  
                <td><?php echo $user->password ?></td>              
                <td><?php echo $user->level ?></td>
                
               
                <td><?php echo anchor('data/edit/'.$user->iduser,'<div class="btn btn-primary"><i class="fa fa-edit"></i></div>')?></td>
                <td onclick="javascript: return confirm('Apakah Anda yakin ingin menghapus') "><?php echo anchor('data/hapus/'.$user->iduser, '<div class="btn btn-danger"><i class="fa fa-trash"></i></div>') ?></td>
            </tr>
            <?php endforeach;?>
        </table>
    </section>
 
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">FORM INPUT DATA </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <form method="post" action="<?php echo base_url().'data/tambah_aksi'?>">
       <div class="form-group">
                <label>ID User</label>
                <input type="text" name="iduser" class="form-control">
            </div>

            <div class="form-group">
                <label>Nama User</label>
                <input type="text" name="namauser" class="form-control">
            </div>

            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control">
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="text" name="password" class="form-control">
            </div>

        
            <div class="form-group">
                <label>Level</label>
                <input type="text" name="level" class="form-control">
            </div>
     
            
            <button type="resset" class="btn btn-danger" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-primary">Simpan</button>

        </form>
      </div>
      <div class="modal-footer">
       
      </div>
    </div>
  </div>
</div>

</div>