<!DOCTYPE html>
<html>
<head>
    <title></title>
    <h1> Data User</h1>
</head>
<body>
    <table style="margin: 20px; auto;"border="1">
        <tr>
                <th>No</th>
                <th>Id user</th>
                <th>Nama User</th>
                <th>Username</th>
                <th>Password</th>                
                <th>Level</th>
        </tr>
        <?php
            $no = 1;
            foreach ($data as $user):?>
            <tr>
                <td><?php echo $no++?></td>  
                <td><?php echo $user->iduser ?></td> 
                <td><?php echo $user->namauser ?></td>  
                <td><?php echo $user->username ?></td>  
                <td><?php echo $user->password ?></td>               
                <td><?php echo $user->level ?></td>
            </tr>

        <?php endforeach; ?>
    </table>
    
    
    <script type="text/javascript">
        window.print();
        
    </script>

</body>
</html>