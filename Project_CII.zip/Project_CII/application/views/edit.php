<div class="content-wrapper">
    <section class="content">
        <?php foreach($data as $data) ?>

        <form action="<?php echo base_url(). 'data/update'; ?>"
        method="post">

        <div  class="from-group">
            <label>ID User</label>
            <input type="text" name="iduser" class="form-control"
            value="<?php echo $data->iduser?>">
        </div><br>

        <div  class="from-group">
            <label>Nama User</label>
            <input type="text" name="namauser" class="form-control"
            value="<?php echo $data->namauser?>">
        </div><br>

        <div  class="from-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control"
            value="<?php echo $data->username?>">
        </div><br>


        <div  class="from-group">
            <label>Password</label>
            <input type="text" name="password" class="form-control"
            value="<?php echo $data->password?>">
        </div><br>

        
        

        <div  class="from-group">
            <label>Level</label>
            <input type="text" name="level" class="form-control"
            value="<?php echo $data->level?>">
        </div><br>

        <button type="resset" class="btn btn-danger" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-primary">Simpan</button>

        </form>
        <?php ?>
        </section>
        </div>  
        